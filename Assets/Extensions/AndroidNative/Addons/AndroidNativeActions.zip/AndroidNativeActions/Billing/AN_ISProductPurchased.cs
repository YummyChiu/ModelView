﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Billing")]
	public class AN_ISProductPurchased : FsmStateAction {

		public FsmString SKU;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			InitAndroidInventoryTask iTask = InitAndroidInventoryTask.Create();
			iTask.ActionComplete += OnInvComplete;
			iTask.ActionFailed += OnInvFailed;
			iTask.Run();
			

		}
		
		private void OnInvComplete() {

			if(AndroidInAppPurchaseManager.instance.inventory.IsProductPurchased(SKU.Value)) {
				Fsm.Event(successEvent);
			} else  {
				Fsm.Event(failEvent);
			}

			Finish();
		}
		
		private void OnInvFailed() {
			Fsm.Event(failEvent);
			Finish();
			
		}
		
		
		
	}
}

using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_LogIn : FsmStateAction {

		public string scopes = "email,publish_actions";


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(SPFacebook.instance.IsLoggedIn) {
				Fsm.Event(successEvent);
				return;
			}

			SPFacebook.instance.OnInitCompleteAction += InitCompleted;
			SPFacebook.instance.Init();
		}

		public void InitCompleted() {
			SPFacebook.Instance.OnAuthCompleteAction += HandleOnAuthCompleteAction;
			SPFacebook.instance.Login(scopes);
		}

		void HandleOnAuthCompleteAction (FB_APIResult res) {
			if(res.Error == null && SPFacebook.instance.IsLoggedIn) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			SPFacebook.Instance.OnAuthCompleteAction -= HandleOnAuthCompleteAction;
			Finish();
		}

	}
}



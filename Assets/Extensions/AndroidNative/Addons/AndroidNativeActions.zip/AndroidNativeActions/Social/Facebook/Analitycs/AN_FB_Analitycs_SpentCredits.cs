﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_Analitycs_SpentCredits : FsmStateAction {
		
		public FsmFloat credit;
		public FsmString contentType;
		public FsmString contentId;
		
		public override void OnEnter() {
			SPFacebookAnalytics.SpentCredits(credit.Value, contentType.Value, contentId.Value);
			Finish ();
		}		
	}
}

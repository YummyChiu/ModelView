using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterPostTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			
			AndroidTwitterManager.Instance.OnPostingCompleteAction += HandleOnPostingCompleteAction;
			AndroidTwitterManager.Instance.Post(message.Value, texture.Value as Texture2D);
			
		}

		void HandleOnPostingCompleteAction (TWResult res) {
			if(res.IsSucceeded) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}
			
			AndroidTwitterManager.Instance.OnPostingCompleteAction -= HandleOnPostingCompleteAction;
			Finish();
		}
	}
}




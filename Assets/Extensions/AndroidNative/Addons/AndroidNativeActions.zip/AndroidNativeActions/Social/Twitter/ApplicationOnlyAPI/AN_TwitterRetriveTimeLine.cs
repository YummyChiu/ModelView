﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterRetriveTimeLine : FsmStateAction {

		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public FsmString[] loadedTweets;
		public FsmString user_id;
		public FsmInt count;

		public override void OnEnter() {	
			TW_UserTimeLineRequest r = TW_UserTimeLineRequest.Create();
			r.ActionComplete += OnTimeLineRequestComplete;

			if (user_id.Value.Length > 0) {
				r.AddParam("user_id", user_id.Value);
			}

			if (count.Value != 0) {
				r.AddParam ("count", count.Value.ToString());
			}
			r.Send();
		}

		private void OnTimeLineRequestComplete(TW_APIRequstResult result) {
						
			if(result.IsSucceeded) {
				loadedTweets = new FsmString[result.tweets.Count];

				for(int i = 0; i < result.tweets.Count; i++) {
					loadedTweets[i].Value = result.tweets[i].text;
				}

				Fsm.Event(successEvent);
				Finish();
			} else {
				Fsm.Event(failEvent);
				Finish();
			}
		}
	}
}

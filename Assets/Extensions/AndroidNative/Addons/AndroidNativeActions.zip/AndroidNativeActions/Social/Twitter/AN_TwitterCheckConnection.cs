﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]	
	public class AN_TwitterCheckConnection : FsmStateAction {
		
		public FsmBool connection;
		
		public FsmEvent twitterConnected;
		public FsmEvent twitterDisconnected;
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			connection.Value = AndroidTwitterManager.instance.IsAuthed || IsInEdditorMode ? true : false;								
			
			Fsm.Event (connection.Value ? twitterConnected : twitterDisconnected);
			
			Finish ();
		}
	}
}

﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - PlayService")]
	public class AN_DeleteSnapshot : FsmStateAction {

		public FsmString SnapshotName;

		public FsmEvent Success;
		public FsmEvent Failure;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if (IsInEdditorMode) {
				Fsm.Event(Success);
				Finish();
			}
			
			GooglePlaySavedGamesManager.ActionGameSaveRemoved += OnGameSaveRemoved;
			GooglePlaySavedGamesManager.instance.DeleteSpanshotByName (SnapshotName.Value);
		}

		private void OnGameSaveRemoved(GP_DeleteSnapshotResult result) {
			GooglePlaySavedGamesManager.ActionGameSaveRemoved -= OnGameSaveRemoved;
			if (result.isSuccess) {
				Fsm.Event(Success);
				Finish ();
			} else {
				Fsm.Event(Failure);
				Finish ();
			}
		}
	}
}

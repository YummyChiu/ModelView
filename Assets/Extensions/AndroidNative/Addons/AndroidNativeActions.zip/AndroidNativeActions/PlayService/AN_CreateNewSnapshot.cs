﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - PlayService")]
	public class AN_CreateNewSnapshot : FsmStateAction {

		public FsmString SnapshotName;
		public FsmString Description;
		public FsmTexture CoverImage;
		public FsmString SnapshotData;
		public FsmInt PlayedTime;

		public FsmEvent Success;
		public FsmEvent Failure;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif

			if (IsInEdditorMode) {
				Fsm.Event(Success);
				Finish();
			}

			GooglePlaySavedGamesManager.ActionGameSaveResult += OnGameSaveResult;
			GooglePlaySavedGamesManager.instance.CreateNewSnapshot (SnapshotName.Value, Description.Value, CoverImage.Value as Texture2D, SnapshotData.Value, (long)PlayedTime.Value);
		}

		private void OnGameSaveResult(GP_SpanshotLoadResult result) {
			GooglePlaySavedGamesManager.ActionGameSaveResult -= OnGameSaveResult;
			if (result.isSuccess) {
				Fsm.Event(Success);
				Finish();
			} else {
				Fsm.Event(Failure);
				Finish();
			}
		}
	}
}

﻿namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - PlayService")]
	public class AN_GetScore : FsmStateAction {
		
		public FsmString leaderboardId;
		public FsmInt score;
		public GPBoardTimeSpan timeSpan;
		public GPCollectionType collection;
		
		
		public override void OnEnter() {
			if(GooglePlayManager.IsLeaderboardsDataLoaded) {
				GetScores();
			} else {
				GooglePlayManager.ActionLeaderboardsLoaded += ActionLeaderboardsLoeaded;
			}
			
		}

		private void ActionLeaderboardsLoeaded (GooglePlayResult obj) {
			GetScores() ;
		}


		public void GetScores() {
			GPLeaderBoard board =  GooglePlayManager.instance.GetLeaderBoard(leaderboardId.Value);
			score.Value  = 0;
			if(board != null) {
				score.Value = (int) board.GetCurrentPlayerScore(timeSpan, collection).score;
			}

			Finish();
		}
		
	}
}
